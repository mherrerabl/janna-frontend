export interface productToPay {
  name: string;
  price: number;
  quantity: number;
}
