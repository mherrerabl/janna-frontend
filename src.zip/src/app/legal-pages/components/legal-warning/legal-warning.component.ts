import { Component } from '@angular/core';

@Component({
  selector: 'app-legal-warning',
  templateUrl: './legal-warning.component.html',
  styleUrl: './legal-warning.component.scss'
})
export class LegalWarningComponent {

}
