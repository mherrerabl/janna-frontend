import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileAdminRoutingModule } from './profile-admin-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ProfileAdminRoutingModule
  ]
})
export class ProfileAdminModule { }
