import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-calendar',
  templateUrl: './icon-calendar.component.html',
})
export class IconCalendarComponent {}
