import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-cart',
  templateUrl: './icon-cart.component.html',
})
export class IconCartComponent {}
