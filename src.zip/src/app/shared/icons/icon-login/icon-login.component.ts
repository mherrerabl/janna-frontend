import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-login',
  templateUrl: './icon-login.component.html',
})
export class IconLoginComponent {}
