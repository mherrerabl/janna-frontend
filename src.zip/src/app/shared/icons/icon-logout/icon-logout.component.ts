import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-logout',
  templateUrl: './icon-logout.component.html',
})
export class IconLogoutComponent {}
