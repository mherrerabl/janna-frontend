import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-register',
  templateUrl: './icon-register.component.html',
})
export class IconRegisterComponent {}
