import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-shop',
  templateUrl: './icon-shop.component.html',
})
export class IconShopComponent {}
