import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-treatment',
  templateUrl: './icon-treatment.component.html',
})
export class IconTreatmentComponent {}
