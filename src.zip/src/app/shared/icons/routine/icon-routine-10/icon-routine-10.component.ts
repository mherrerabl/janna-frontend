import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-routine-10',
  templateUrl: './icon-routine-10.component.html',
})
export class IconRoutine10Component {}
