import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-routine-2',
  templateUrl: './icon-routine-2.component.html',
})
export class IconRoutine2Component {}
