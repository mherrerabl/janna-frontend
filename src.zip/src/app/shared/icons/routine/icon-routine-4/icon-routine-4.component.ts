import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-routine-4',
  templateUrl: './icon-routine-4.component.html',
})
export class IconRoutine4Component {}
