import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-routine-5',
  templateUrl: './icon-routine-5.component.html',
})
export class IconRoutine5Component {}
