import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-routine-6',
  templateUrl: './icon-routine-6.component.html',
})
export class IconRoutine6Component {}
