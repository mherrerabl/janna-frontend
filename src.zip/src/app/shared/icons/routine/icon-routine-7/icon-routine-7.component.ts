import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-routine-7',
  templateUrl: './icon-routine-7.component.html',
})
export class IconRoutine7Component {}
