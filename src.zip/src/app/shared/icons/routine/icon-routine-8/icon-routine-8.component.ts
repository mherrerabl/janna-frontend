import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-routine-8',
  templateUrl: './icon-routine-8.component.html',
})
export class IconRoutine8Component {}
