import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-routine-9',
  templateUrl: './icon-routine-9.component.html',
})
export class IconRoutine9Component {}
