export interface BreadcrumbDTO {
  name: string;
  url: string;
}
