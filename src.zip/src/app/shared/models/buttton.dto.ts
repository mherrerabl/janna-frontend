export interface ButtonDTO {
  name: string;
  type: string;
  size: string;
}
