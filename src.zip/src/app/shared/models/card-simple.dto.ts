import { ImageClass } from '../../images/models/image';

export interface CardSimpleDTO {
  title: string;
  image: ImageClass;
  url: string;
}
