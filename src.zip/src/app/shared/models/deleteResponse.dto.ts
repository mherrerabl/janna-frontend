export interface deleteResponse {
  affected: number;
}
