export interface InputErrorDTO {
  type: string;
  message: string;
}
