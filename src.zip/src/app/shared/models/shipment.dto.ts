export interface ShipmentDTO {
  method: string;
  address: string | null;
}
