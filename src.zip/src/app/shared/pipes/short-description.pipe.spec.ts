import { ShortDescriptionPipe } from './short-description.pipe';

describe('ShortDescriptionPipe', () => {
  it('create an instance', () => {
    const pipe = new ShortDescriptionPipe();
    expect(pipe).toBeTruthy();
  });
});
