export interface UserDTO {
  email: string;
  password?: string;
  token?: string;
  _token?: any;
}
