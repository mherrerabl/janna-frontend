export const environment = {
  production: false,
  API_URL: 'http://localhost:8000',
  stripe_public:
    'pk_test_51PFKQiEj6XaLEnGsVZ2mZpIfbaKeCAlVB3WHjAe1DwCVCrDJ9GEePSuX4bzOrTXghIDvuaBB1BoKYAARFwIdaDlb0090pynHDz',
};
