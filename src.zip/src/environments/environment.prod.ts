export const environment = {
  production: true,
  API_URL: 'https://18.101.19.115',
  stripe_public:
    'pk_test_51PFKQiEj6XaLEnGsVZ2mZpIfbaKeCAlVB3WHjAe1DwCVCrDJ9GEePSuX4bzOrTXghIDvuaBB1BoKYAARFwIdaDlb0090pynHDz',
};
